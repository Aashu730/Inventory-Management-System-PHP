<?php
session_start();
if (!isset($_SESSION['loggedin'])) { header("Location: login.php"); exit; }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: url('desk.jpg') no-repeat center center fixed;
      background-size: cover;
      color: #fff;
    }
    .nav {
      background: rgba(0,0,0,0.7);
      padding: 10px;
      text-align: center;
    }
    .nav a {
      margin: 0 15px;
      color: #fff;
      text-decoration: none;
      font-weight: bold;
    }
    .nav a:hover {
      text-decoration: underline;
    }
    .content {
      padding: 40px;
      background-color: rgba(0,0,0,0.6);
      margin: 40px auto;
      width: 80%;
      border-radius: 12px;
    }
  </style>
</head>
<body>
  <div class="nav">
    <a href="dashboard.php">Dashboard</a>
    <a href="add_item.php">Add Item</a>
    <a href="view_items.php">View Items</a>
    <a href="payment.php">Payment</a>
    <a href="logout.php">Logout</a>
  </div>
  <div class="content">
    <h1>Welcome to the Inventory Dashboard</h1>
    <p>Track and manage your stock here.</p>
  </div>
</body>
</html>