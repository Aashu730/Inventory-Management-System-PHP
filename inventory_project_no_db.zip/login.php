<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['user'] === 'admin' && $_POST['pass'] === '1234') {
        $_SESSION['loggedin'] = true;
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Invalid login";
    }
}
?>
<!DOCTYPE html>
<html><head><title>Login</title>
<style>
  body {
    font-family: Arial;
    background: url('desk.jpg') no-repeat center center fixed;
    background-size: cover;
    color: white;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  form {
    background: rgba(0,0,0,0.7);
    padding: 20px;
    border-radius: 10px;
  }
  input, button {
    margin: 10px 0;
    width: 100%;
    padding: 10px;
  }
</style>
</head><body>
<form method="post">
  <h2>Login</h2>
  <input name="user" placeholder="Username" required>
  <input name="pass" type="password" placeholder="Password" required>
  <button type="submit">Login</button>
  <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
</form>
</body></html>